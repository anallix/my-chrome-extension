console.log('Content script carregado');
