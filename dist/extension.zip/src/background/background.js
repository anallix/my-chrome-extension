console.log('Background service worker ativo');
